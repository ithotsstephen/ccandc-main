CC&C Solutions static website build
===================================

Target URL: https://ccandcsolutions.com/demo/main/

Hostinger deployment:
1. Open Hostinger File Manager and go to public_html.
2. Upload this ZIP into public_html and extract it there.
3. Confirm the extracted files are at public_html/demo/main/index.html
   (the archive contains the demo/main folder path).
4. Visit https://ccandcsolutions.com/demo/main/ and test the training page.

The included .htaccess enables SPA route fallback for this subdirectory.
This is a static frontend build and does not include the server application.
